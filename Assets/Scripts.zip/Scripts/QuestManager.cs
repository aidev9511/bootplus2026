using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using TMPro;

public class QuestManager : MonoBehaviour
{
    [Header("Level Settings")]
    public int currentLevel = 1;
    public SlimeSpawner slimeSpawner;
    public float nextLevelDelay = 1.2f;

    [Header("Quest UI")]
    public TMP_Text countText;
    public TMP_Text levelText;
    public RectTransform progressFill;

    [Header("Quest Complete Popup")]
    public GameObject questCompletePanel;
    public TMP_Text completeTitleText;
    public TMP_Text completeMessageText;

    private int targetKills;
    private int currentKills;
    private float maxFillWidth;
    private bool isLevelTransitioning;

    void Awake()
    {
        if (progressFill != null)
        {
            maxFillWidth = progressFill.rect.width;
        }
    }

    void Start()
    {
        Time.timeScale = 1f;

        if (questCompletePanel != null)
        {
            questCompletePanel.SetActive(false);
        }

        StartLevel(1);
    }

    // 새 레벨 시작
    void StartLevel(int level)
    {
        currentLevel = level;
        currentKills = 0;
        isLevelTransitioning = false;

        if (slimeSpawner == null)
        {
            Debug.LogError(
                "SlimeSpawner가 연결되지 않았습니다."
            );
            return;
        }

        targetKills = slimeSpawner.SpawnLevel(level);

        if (targetKills <= 0)
        {
            Debug.LogError(
                "슬라임이 생성되지 않았습니다. " +
                "Ground Layer와 스폰 영역을 확인하세요."
            );
            return;
        }

        UpdateQuestUI();

        Debug.Log(
            "LEVEL " + currentLevel +
            " START! " + targetKills + " slimes."
        );
    }

    // 슬라임 사망 시 호출
    public void AddKill()
    {
        if (isLevelTransitioning || targetKills <= 0)
            return;

        currentKills = Mathf.Min(
            currentKills + 1,
            targetKills
        );

        UpdateQuestUI();

        Debug.Log(
            "LEVEL " + currentLevel +
            " : Slimes Defeated " +
            currentKills + "/" + targetKills
        );

        if (currentKills >= targetKills)
        {
            isLevelTransitioning = true;
            StartCoroutine(FinishLevel());
        }
    }

    void UpdateQuestUI()
    {
        if (countText != null)
        {
            countText.text =
                "Slimes Defeated: " +
                currentKills + " / " + targetKills;
        }

        if (levelText != null)
        {
            levelText.text = "LEVEL " + currentLevel;
        }

        if (progressFill != null && targetKills > 0)
        {
            float ratio =
                (float)currentKills / targetKills;

            progressFill.gameObject.SetActive(
                currentKills > 0
            );

            progressFill.SetSizeWithCurrentAnchors(
                RectTransform.Axis.Horizontal,
                maxFillWidth * ratio
            );
        }
    }

    IEnumerator FinishLevel()
    {
        // 기존 사망 애니메이션과 파티클 시간 확보
        yield return new WaitForSeconds(nextLevelDelay);

        if (currentLevel < slimeSpawner.levels.Length)
        {
            StartLevel(currentLevel + 1);
        }
        else
        {
            CompleteQuest();
        }
    }

    void CompleteQuest()
    {
        Debug.Log("ALL LEVELS COMPLETE!");

        if (completeTitleText != null)
        {
            completeTitleText.text = "QUEST COMPLETE!";
        }

        if (completeMessageText != null)
        {
            completeMessageText.text =
                "All 3 levels cleared!";
        }

        if (questCompletePanel != null)
        {
            questCompletePanel.SetActive(true);
        }

        Time.timeScale = 0f;
    }

    public void PlayAgain()
    {
        Time.timeScale = 1f;

        SceneManager.LoadScene(
            SceneManager.GetActiveScene().name
        );
    }
}